<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.pagetitlesuffix
 *
 * @copyright   (C) 2022 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

/**
 * System plugin that attaches the text from the parameter field to each headline.
 *
 * @since  4.0.0
 */
class PlgSystemPageTitleSuffix extends CMSPlugin
{
    /**
     * Load the language file on instantiation
     * 
     * @var    boolean
     * @since  4.0.0
     */ 
	 

    /**
     * Application object.
     * 
     * @var    JApplicationCms
     * @since  4.0.0
     */
	 
    protected $app;

    /**
     * Constructor.
     *
     * @param   object  &$subject  The object to observe.
     * @param   array   $config    An optional associative array of configuration settings.
     *
     * @since  4.0.0
     */
	
    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
    }

    /**
     * Listener for the `onAfterDispatch` event
     * 
     * @return  void
     *
     * @since   4.0.0
     */
	 
    public function onAfterDispatch()
    {
        $app = JFactory::getApplication();
        $isAdmin = $app->isClient('administrator');

        //for backend

        if ($isAdmin) {
            $pagetitlesuffix_value = $this->params->get('pagetitlesuffix_value','');
            JFactory::getDocument()->addScriptDeclaration("
            window.onload=function(){document.querySelectorAll('h1, h2, h3, h4, h5, h6').forEach(function(heading){heading.innerHTML+='$pagetitlesuffix_value'})}
                 ");
            return;
        }
    }
}